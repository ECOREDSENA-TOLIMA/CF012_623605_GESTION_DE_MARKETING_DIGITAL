function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6E6dsbrbQhY":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

